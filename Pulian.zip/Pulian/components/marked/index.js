export default './lib/marked'
